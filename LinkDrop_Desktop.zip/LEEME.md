# LinkDrop 1.2 — aplicación de escritorio

**Windows 10/11, 64 bits.** Abre `LinkDrop_Desktop.exe` para usar LinkDrop en su propia ventana. No abre el navegador ni inicia un servidor en `localhost`: la interfaz va incluida en el ejecutable y se comunica con Go mediante un puente interno.

Necesita **Microsoft Edge WebView2 Runtime**, normalmente presente en Windows 10/11 actualizados. Si falta, LinkDrop muestra un mensaje para instalarlo desde [Microsoft](https://developer.microsoft.com/microsoft-edge/webview2/). No necesitas instalar Go para ejecutar la aplicación.

El archivo anterior `LinkDrop_1.1_Rapido.exe` conserva el comportamiento antiguo; usa el nuevo `LinkDrop_Desktop.exe`. Al cerrar la ventana se cancela la descarga activa y termina la aplicación.

Esta versión **no lleva FFmpeg ni yt-dlp incorporados dentro del EXE**. Se mejoró para evitar volver a descargar los componentes existentes:

- Al iniciar, busca `bin/yt-dlp.exe`, `bin/ffmpeg.exe` y `bin/ffprobe.exe` junto a LinkDrop.exe (versión portátil).
- Si no están, reutiliza los componentes de instalaciones anteriores bajo `%APPDATA%/LinkDrop/bin` (o la carpeta de configuración de Windows) y las herramientas disponibles en PATH.
- Si hace falta FFmpeg, primero prueba el paquete oficial compacto de Gyan (~34 MB), extrayéndolo con `tar.exe` de Windows. Si la extracción de 7z no es compatible con tu versión de Windows, utiliza el ZIP como alternativa.
- Si yt-dlp está instalado, no lo vuelve a descargar.
- La primera preparación necesita conexión solo si faltan componentes. Las siguientes ejecuciones los reutilizan.

## Inicio

1. Ejecutar `LinkDrop_Desktop.exe`.
2. Si dice LISTO, no hay que instalar nada.
3. Si dice NO LISTO, pulsar **Preparar componentes**.
4. Pegar un enlace de contenido disponible y autorizado, elegir audio/video, calidad, y descargar.

## Crear paquete portátil completo manualmente

Cuando tengas `yt-dlp.exe`, `ffmpeg.exe` y `ffprobe.exe` de sus distribuidores originales, colócalos en una carpeta `bin` junto al .exe:

```
LinkDrop/
    LinkDrop_Desktop.exe
    bin/
        yt-dlp.exe
        ffmpeg.exe
        ffprobe.exe
```

En ese caso LinkDrop detecta las tres herramientas al iniciar **sin descargarlas ni instalarlas**. Es posible mover toda la carpeta a otro PC Windows x64.

### Origen de motores externos

- yt-dlp: https://github.com/yt-dlp/yt-dlp/releases/latest
- FFmpeg Windows: https://www.gyan.dev/ffmpeg/builds/

## Compilar desde el código fuente

Requiere Go 1.23 o posterior. Ejecutar desde `LinkDrop_1.1_codigo_fuente`:

```powershell
go mod download
go test ./...
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"
go build -trimpath -ldflags="-H windowsgui -s -w" -o ../LinkDrop_Desktop.exe .
```

Desde Linux se puede generar el mismo ejecutable:

```sh
go mod download
go test -race ./...
node desktop_bridge_test.js # opcional: prueba JavaScript, requiere Node.js
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H windowsgui -s -w' -o ../LinkDrop_Desktop.exe .
```

En Windows la interfaz se carga directamente en una ventana WebView2, sin un puerto HTTP. Las consultas lentas se ejecutan fuera del hilo de la ventana para mantenerla operativa. La compilación usa el subsistema gráfico de Windows y no muestra una consola. El cargador de WebView2 va incluido en el ejecutable; el Runtime es un requisito del sistema.

En Linux/macOS se conserva el servidor HTTP únicamente para desarrollo y pruebas del motor; no es el comportamiento de la distribución Windows. En este entorno Linux se verificaron las pruebas Go, el puente JavaScript y una descarga/conversión a FLAC con un video local generado con FFmpeg. Para pruebas de escritorio y de integración en Windows se necesita un equipo Windows.

Distribuye también `LinkDrop_Desktop_LICENCIAS.txt`, incluido en el paquete ZIP, con el ejecutable.

## Limitaciones

- Solo para contenido que tienes derecho a descargar. No permite sortear DRM.
- No ha sido probado directamente en un PC Windows ni en sitios reales desde este entorno.
- No se garantiza el funcionamiento en cualquier sitio ni la extracción 7z con versiones antiguas de Windows.
